﻿using System;
using System.Threading;
namespace thread_tarea1
{
    class Program
    {
		
		//Katherine Adriana German 20186884
		//Jose Ismael Vasquez 20186842
		
        static void Main(string[] args)
        {

            Console.WriteLine("Multiplication Table  1 to 12");
            Thread1();
            Thread2();
            Thread3();
            Thread4();
            Thread5();
            Thread6();
            Thread7();
            Thread8();
            Thread9();
            Thread10();
            Thread11();
            Thread12();
            Console.ReadLine();
        }


        public static void Table1()
        {
            Console.WriteLine("-----------Table del 1 -----------");
            int result;
            int num = 1;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }

        public static void Table2()
        {

            Console.WriteLine("-----------Table del 2 -----------");
            int result;
            int num = 2;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table3()
        {

            Console.WriteLine("-----------Table del 3 -----------");
            int result;
            int num = 3;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }

        public static void Table4()
        {

            Console.WriteLine("-----------Table del 4 -----------");
            int result;
            int num = 4;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table5()
        {

            Console.WriteLine("-----------Table del 5 -----------");
            int result;
            int num = 5;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table6()
        {

            Console.WriteLine("-----------Table del 6 -----------");
            int result;
            int num = 6;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table7()
        {

            Console.WriteLine("-----------Table del 7 -----------");
            int result;
            int num = 7;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table8()
        {

            Console.WriteLine("-----------Table del 8 -----------");
            int result;
            int num = 8;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table9()
        {

            Console.WriteLine("-----------Table del 9 -----------");
            int result;
            int num = 9;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table10()
        {
            Console.WriteLine("-----------Table del  10 -----------");
            int result;
            int num = 10;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table11()
        {

            Console.WriteLine("-----------Table del  11 -----------");
            int result;
            int num = 11;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        public static void Table12()
        {

            Console.WriteLine("-----------Table del  12 -----------");
            int result;
            int num = 12;
            for (int k = 1; k <= 12; k++)
            {

                result = num * k;

                Console.WriteLine(num + " * " + k + " = " + result);
            }
        }
        private static void Thread1()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table1));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();


        }
        private static void Thread2()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table2));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread3()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table3));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread4()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table4));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }

        private static void Thread5()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table5));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread6()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table6));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread7()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table7));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread8()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table8));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread9()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table9));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread10()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table10));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread11()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table11));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }
        private static void Thread12()
        {
            System.Threading.Thread thread;
            thread = new System.Threading.Thread(new System.Threading.ThreadStart(Table12));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();
            thread.Join();

        }

    }
}

